package model;

public class Calculadora {

	
	public int sumar(int a, int b) {
		return a+b;
	}
}
